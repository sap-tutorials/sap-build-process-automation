/* global QUnit */

sap.ui.require(["ordersmgtnsp/workflowuimodule/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
