sap.ui.define([
	"ordersmgtnsp/workflow-ui-module/test/unit/controller/orderApprovalForm.controller"
], function () {
	"use strict";
});
